import { Col, Container, Row } from "react-bootstrap";
import "./Header.css";

const header = () => {
	return (
		<Container fluid>
			<Row className="Header">
				<Col></Col>
				<Col><a href="/"><img className="Header-logo" src="images/logo_90.png" alt="logo"/></a></Col>
				<Col>
					<Row className="Header-right">

						{/* 로그인 되었을 때 */}
						<Col xs={3}><a href="/write">공구 모집 글쓰기</a></Col>
						<Col className="Menu-select" xs={2}>
							<a href="/">마이페이지</a>
							<div className="Menu-select-box">
								<ul>
									<li><a href="/">나의 정보 수정</a></li>
									<li><a href="/">공구 참여 현황</a></li>
									<li><a href="/">나의 공구 모집</a></li>
								</ul>
							</div>
						</Col>
						<Col xs={2}><a href="/">로그아웃</a></Col>
						<Col xs={6}></Col>

						{/* 로그인 안되었을 때 */}
						{/* <Col xs={4}></Col>
						<Col>로그인</Col>
						<Col xs={6}></Col> */}
					</Row>
				</Col>
			</Row>
			<Row className="Header-category">
				<Col />
				<Col xs={8}>
					<button className="Header-button Header-button-clicked">실시간 공구</button>
					<button className="Header-button">실시간 공구</button>
					<button className="Header-button">실시간 공구</button>
					<button className="Header-button">실시간 공구</button>
					<button className="Header-button">실시간 공구</button>
				</Col>
				<Col />
			</Row>
			<Row  className="Header-line">
				<hr style={{color: "#0D4212"}}/>
			</Row>
		</Container>
	);
};

export default header;
